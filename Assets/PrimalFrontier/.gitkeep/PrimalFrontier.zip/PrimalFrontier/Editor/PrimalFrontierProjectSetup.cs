#if UNITY_EDITOR
using UnityEditor; using UnityEditor.SceneManagement; using UnityEngine; using PrimalFrontier;
[InitializeOnLoad]
public static class PrimalFrontierProjectSetup {
 static PrimalFrontierProjectSetup(){ EditorApplication.delayCall += EnsureScene; }
 static void EnsureScene(){ if(EditorApplication.isPlayingOrWillChangePlaymode)return; const string path="Assets/PrimalFrontier/Scenes/PrimalFrontier_Demo.unity"; var scene=EditorSceneManager.OpenScene(path,OpenSceneMode.Single); if(!GameObject.Find("PRIMAL FRONTIER BOOTSTRAP")){new GameObject("PRIMAL FRONTIER BOOTSTRAP").AddComponent<PrimalFrontierBootstrap>();EditorSceneManager.SaveScene(scene,path);} EditorBuildSettings.scenes=new[]{new EditorBuildSettingsScene(path,true)}; }
 [MenuItem("PRIMAL FRONTIER/Build Web Demo")]
 public static void BuildWeb(){ System.IO.Directory.CreateDirectory("Build/Web"); BuildPipeline.BuildPlayer(new[]{"Assets/PrimalFrontier/Scenes/PrimalFrontier_Demo.unity"},"Build/Web",BuildTarget.WebGL,BuildOptions.None); }
}
#endif
